import javax.swing.*; 
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
public class SearchingPanel extends JPanel
{
    private JList Jconpl;
    
    public SearchingPanel(String[] computer)
    {
        Jconpl = new JList(computer);
        
        setPreferredSize(new Dimension (510,329));
        setLayout(null);
        
        add(Jconpl);
        
        Jconpl.setBounds(30,40,450,230);
    }
}