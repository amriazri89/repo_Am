public class LinkedList
{
    private Node first;
    private Node last;
    private Node current;
    private String name;
    
    //const
    public LinkedList()
    {
       //name = h;
       first = last = current = null;
    }
    //list const
    /*public LinkedList()
    {
        this("Linked List");        
    }*/
    public int size()
    {
        return size();
    }
    //add first
    /*public void addFirst(Object insertItem){
        if(isEmpty()){
            first = last = new Node(insertItem);
        }
        else{
            first = new Node(insertItem, first);}
        }*/
     public void insertAtBack(Object insertItem){
        if(isEmpty()){
            first = last = new Node(insertItem);
        }
        else{
            last = last.next = new Node(insertItem);
        }
    }
    //add last
    public void addLast(Object insertItem)
    {
        if (isEmpty())
        {
            first = last = new Node(insertItem);
        }
        else
        {
            last = last.next = new Node(insertItem);
        }
    }
    
    public boolean isEmpty()
    {
        return first == null;
    }
    
    public Object getFirst()
    {
        if(isEmpty())
            return null;
        else
        {
            current = first;
            return current.data;
        }
    }
    
    public Object getNext()
    {
        if(current != last)
        {
            current = current.next;
            return current.data;
        }
        else
            return null;
    }
    
    public Object removeFirst() throws EmptyListException
    {
        Object removeItem =null;
        if(isEmpty())
        {
            throw new EmptyListException(name);
        }
        removeItem = first.data; 
        
        if(first.equals(last))
        {
            first = last = null;
        }
        else
        {
            first = first.next;
        }
        return removeItem;
    }
    // Remove The Data
     public Object remove() throws EmptyListException
    {
        Object removeItem =null;
        if(isEmpty())
            throw new EmptyListException(name);
        
        removeItem = current.data;//Retrieve the data 
        if(first.equals(last))
        {
            first = last = null;
        }
        else if(current == first)
        {
            first = first.next;
            current = current.next;
        }
        else if(current == last)
        {
            last = current;
            current.next = null;
        }
        else
        {
            current = current.next;
        }
        return removeItem;
    }
    //Bubble Sort
    public void bubbleSort()
    {
        Node current = first;
        Node index = null;
        
        Object temp;
        while(current != null)
        {
            index = current.next;
            while(index!=null)
            {
                Biryani b1 = (Biryani)current.data;
                Biryani b2 = (Biryani)index.data;
                
                if(b1.getPrice() > b2.getPrice())
                {
                    temp = current.data;
                    current.data = index.data;
                    index.data = temp;
                }
                index = index.next;
            }
            current = current.next;
        }
    }
}