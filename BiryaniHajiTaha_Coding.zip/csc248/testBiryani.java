import java.util.Scanner;
import java.io.*;
import java.util.StringTokenizer;
import java.text.DecimalFormat;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class testBiryani
{
    public static void main(String [] args)throws IOException
    {
        try
        {
            //All information Insert in the Biryani LinkedList 
            LinkedList BiryaniLL = new LinkedList();

            BufferedReader br = new BufferedReader(new FileReader("BiryaniData.txt"));
            String in = null;
            Scanner scan = new Scanner(System.in);
            scan.useDelimiter("\n");
            DecimalFormat df = new DecimalFormat("0.00");

            String custName;
            char setType;
            int quantity;     
            boolean delivery; 
            double price;
            int i = 0;
            while((in=br.readLine())!=null)
            {
                StringTokenizer st = new StringTokenizer(in, ";"); 
                custName = st.nextToken();
                setType  = st.nextToken().charAt(0);
                quantity = Integer.parseInt(st.nextToken());
                delivery = Boolean.parseBoolean(st.nextToken());
                price = Double.parseDouble(st.nextToken());

                Biryani bir = new Biryani(custName,setType,quantity,delivery,price);
                BiryaniLL.insertAtBack(bir);
            }

            /**SORTING**/
            System.out.println("\nBIRYANI HAJI TAHA  ");
            System.out.println("\nList Of The Total Price, Sort In Ascending Order... ");
            Biryani b;
            BiryaniLL.bubbleSort();
            b = (Biryani)BiryaniLL.getFirst();
            while (b != null)
            {
                System.out.println("\n========== CUSTOMER "  + (1 + i) + " ==========" + b.toString() +
                                   "\n================================");
                i++;
                b = (Biryani)BiryaniLL.getNext();
            }           

            //Insert Different Biryani Set A,B & C in the Linked List
            LinkedList BiryaniListA = new LinkedList ();
            LinkedList BiryaniListB = new LinkedList ();
            LinkedList BiryaniListC = new LinkedList ();
            LinkedList BiryaniOthersType = new LinkedList();
            b = (Biryani)BiryaniLL.getFirst();
            while(b != null)
            {
                if(b.getSetType() == 'A' )
                {
                    BiryaniListA.insertAtBack(b);
                }
                else if(b.getSetType() == 'B')
                {
                    BiryaniListB.insertAtBack(b);  
                }
                else if(b.getSetType() == 'C')
                {
                    BiryaniListC.insertAtBack(b);                              
                }

                b = (Biryani)BiryaniLL.getNext();
            }

            //Remove the data in BiryaniList using Queue method
            Queue biryaniQ = new Queue();
            while (!BiryaniLL.isEmpty())
            {                
                Biryani bq = (Biryani)BiryaniLL.removeFirst();
                biryaniQ.enqueue(bq);  
            }

            System.out.println("\n==**==**==**==**==**==**==**==**==**==**==**==**=**==**==**");
            System.out.println("\n.......................................");
            //Test if BiryaniLL has been remove or not
            System.out.println("\n The BiryaniLL Data After Remove... "); 
            Biryani bq2 = (Biryani)BiryaniLL.getFirst();
            if(bq2 == null)
            {
                System.out.println("\n--------------No Data---------------");
            }
            System.out.println("\n.......................................");

            /**AVERAGE && COUNTING**/
            
            //Count The Total Orders of Biryani
            int countOrderA = 0,countOrderB = 0,countOrderC = 0;
            double totSumA = 0.00, totSumB = 0.00, totSumC = 0.00;
            double totAvgA = 0.00, totAvgB = 0.00, totAvgC = 0.00;
            b = (Biryani)BiryaniListA.getFirst();
            while (b != null)
            {
                if(b.getSetType() == 'A')
                {
                    totSumA += b.getPrice();
                    countOrderA++;
                }
                b = (Biryani)BiryaniListA.getNext();
            }
            b = (Biryani)BiryaniListB.getFirst();
            while (b != null)
            {
                if(b.getSetType() == 'B')
                {
                    totSumB += b.getPrice();
                    countOrderB++;
                }
                b = (Biryani)BiryaniListB.getNext();
            }
            b = (Biryani)BiryaniListC.getFirst();
            while (b != null)
            {
                if(b.getSetType() == 'C')
                {
                    totSumC += b.getPrice();
                    countOrderC++;
                }
                b = (Biryani)BiryaniListC.getNext();
            }
            
            //Calculation For The Average
            totAvgA = totSumA / countOrderA;
            totAvgB = totSumB / countOrderB;
            totAvgC = totSumC / countOrderC;

            System.out.println("\n Total Average For Biryani Set A : RM"+ df.format(totAvgA));
            System.out.println(" Total Average For Biryani Set B : RM"+ df.format(totAvgB));
            System.out.println(" Total Average For Biryani Set C : RM"+ df.format(totAvgC));
            System.out.println("\n");

            System.out.println(" Total Count For Biryani Set A :" + countOrderA);
            System.out.println(" Total Count For Biryani Set B :" + countOrderB);
            System.out.println(" Total Count For Biryani Set C :" + countOrderC);
            System.out.println("\n");

            /** MAXIMUM **/
            double MaxTotPriceA = 0.00, MaxTotPriceB = 0.00, MaxTotPriceC = 0.00;
            b = (Biryani)BiryaniListA.getFirst();
            while (b != null)
            {
                if(b.getPrice() > MaxTotPriceA)
                    MaxTotPriceA = b.getPrice();

                b = (Biryani)BiryaniListA.getNext();
            }
            b = (Biryani)BiryaniListB.getFirst();
            while (b != null)
            {
                if(b.getPrice() > MaxTotPriceB)
                    MaxTotPriceB = b.getPrice();

                b = (Biryani)BiryaniListB.getNext();
            }
            b = (Biryani)BiryaniListC.getFirst();
            while (b != null)
            {
                if(b.getPrice() > MaxTotPriceC)
                    MaxTotPriceC = b.getPrice();

                b = (Biryani)BiryaniListC.getNext();
            }
            System.out.println(" The Maximum Total Price For Biryani Set A is :RM" + df.format(MaxTotPriceA));    
            System.out.println(" The Maximum Total Price For Biryani Set B is :RM" + df.format(MaxTotPriceB));    
            System.out.println(" The Maximum Total Price For Biryani Set C is :RM" + df.format(MaxTotPriceC));   

            System.out.println("\n==**==**==**==**==**==**==**==**==**==**==**==**=**==**==**");

            /** SEACRHING && SET NEW PRICE **/
            Biryani tempQ;
            Queue biryaniDelivery = new Queue();
            Queue tempQueue = new Queue();
            double totalPrice = 0.00,charge = 10.00;
            while(!biryaniQ.isEmpty())
            {
                tempQ = (Biryani)biryaniQ.dequeue();
                tempQueue.enqueue(tempQ);
                if(tempQ.getDelivery() == true )
                {
                    totalPrice = tempQ.getPrice() + charge;
                    tempQ.setPrice(totalPrice);
                }
                biryaniDelivery.enqueue(tempQ);
            }
            while(!tempQueue.isEmpty()){ biryaniDelivery.enqueue(tempQueue.dequeue());} 

            System.out.print("\nPlease Insert Customer Name With Delivery Order : " + "\n");
            String searchName = scan.nextLine();
            boolean found = false;
            Queue displayQ= new Queue();
            Biryani Biryanifound = null;
            while(!biryaniDelivery.isEmpty())
            {
                tempQ = (Biryani)biryaniDelivery.dequeue();
                tempQueue.enqueue(tempQ);
                if(tempQ.getCustName().equalsIgnoreCase(searchName) && tempQ.getDelivery() == true)
                {
                    found = true;
                    Biryanifound = tempQ;
                    displayQ.enqueue(tempQ);

                }
            }
            
            Object DisInfo;
            if(found)
            {
                DisInfo = (Biryani)displayQ.dequeue();
                System.out.println("\nThe Information After Add-On Charge For The Delivery : " +
                                   "\n________________________________________________ "  +
                                             DisInfo.toString() +
                                   "\n________________________________________________ "); 
            }
            else
            { 
                System.out.println("\nCustomer Name Not Found in The List!!"); 
            }
            

            String[]display = new String[10];
            String text = "";
            if(found)
            {
                display[0] = "The Information After Add-On Charge For The Delivery : ";
                display[1] = "________________________________________________ "  ;
                display[2] = "Customer Name  : " + Biryanifound.getCustName()  ;
                display[3] = "Type Of Biryani Set : " + Biryanifound.getSetType() ;
                display[4] = "Quantity Of Orders  : " + Biryanifound.getQuantity() ;
                display[5] = "Status Delivery   : "   + Biryanifound.getDelivery() ;
                display[6] = "Total Price       : RM" + df.format(Biryanifound.getPrice()); 
                display[7] = "________________________________________________ "; 
            }
            else
            { 
                //System.out.println("\nCustomer Name Not Found in The List!!"); 
                display[0] = "\nCustomer Name Not Found in The List!!";
            }

            /**DISPLAY SEACRHING PANEL**/
            JFrame myFrame;
            //JPanel myPanel;
            
            myFrame = new JFrame("SEARCHING INFORMATION ");
            myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
            myFrame.getContentPane().add(new SearchingPanel(display));
            myFrame.pack();
            myFrame.setVisible (true);
            
            br.close();
        }
        catch (FileNotFoundException fnfe){System.err.println(fnfe.getMessage());}
        catch (EOFException eof){System.out.println(eof.getMessage());}
        catch (NumberFormatException nfe){System.out.println(nfe.getMessage());}
        catch (Exception e){System.out.println(e.getMessage());}
    }
}