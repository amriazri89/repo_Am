import java.util.LinkedList;
public class Queue
{
    protected LinkedList list;
    
    //default constructor
    public Queue()
    {
        list = new LinkedList();
    }
    //method empty
    public boolean isEmpty()
    {
        return list.isEmpty();
    }
    //method size
    public int size()
    {
        return list.size();
    }
    //method enqueue
    public void enqueue(Object element)
    {
        list.addLast(element);
    }
    //method dequeue
    public Object dequeue()
    {
        return list.removeFirst();
    }
    //method front
    public Object front()
    {
        return list.getFirst();
    }
    //method last or rear
    public Object last()
    {
        return list.getLast();
    }
}//Queue class
