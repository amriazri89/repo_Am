public class Node
{
    Object data;
    Node next;
    
    Node(Object o)
    {
        this(o, null);
    }
    
    Node(Object o, Node n)
    {
        data = o;
        next = n;
    }
    
    Object getObject()
    {
        return data;
    }
    
    Node getLink()
    {
        return next;
    }
}