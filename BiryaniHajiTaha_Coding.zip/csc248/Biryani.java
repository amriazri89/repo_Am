import java.text.DecimalFormat;
public class Biryani
{
    private String custName;  //Example Name : Azrul Bin Azry
    private char setType;     //Set A - BiryaniAyam - RM10.50/ Set B BiryaniDaging - RM12.50/Set C-BiryaniKambing - RM15.50
    private int quantity;     //2, 4 ,10, 14
    private boolean delivery; //Status Delivery,If true ( Add-On chargeDelivery = RM10)
    private double price;     //Total Food Price Of Orders
    
    public Biryani(String cn,char s,int q,boolean d,double p)
    {
        custName = cn;
        setType  = s;
        quantity = q;
        delivery = d;
        price    = p;      
    }
    
    //getters
    public String getCustName(){return custName;}
    public char getSetType(){return setType;}
    public int getQuantity(){return quantity;}
    public boolean getDelivery(){return delivery;}
    public double getPrice(){return price;}
    
    //Setters
    public void setCustName(String newCustName){custName = newCustName ;}
    public void setOrderID(char newSetType){setType = newSetType; }
    public void setQuantity(int newQuantity){quantity = newQuantity ;}
    public void setDelivery(boolean newDelivery){delivery = newDelivery ;}
    public void setPrice(double newPrice){price = newPrice ;}
        
    DecimalFormat df = new DecimalFormat("0.00");
    public String toString()
    {
        return "\nCustomer Name : " + custName +
               "\nType Of Biryani Set : " + setType +
               "\nQuantity Of Orders  : " + quantity +
               "\nStatus Delivery    : "   + delivery +
               "\nTotal Price        : RM" + df.format(price); 
    }  
}
